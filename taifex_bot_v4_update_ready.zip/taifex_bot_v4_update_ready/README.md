# TAIFEX Bot V4 - 更新檢查 + Shioaji 預留版

V4 功能：
- 保留 V3 保證金風控 GUI
- 新增版本號
- 新增「檢查更新」按鈕
- 新增 `version.json`
- 預留 Shioaji 真實行情介面
- 目前仍使用模擬行情，不真實下單

## 執行

```bash
cd taifex_bot_v4_update_ready
python3 main_gui.py
```

## 安裝套件

```bash
pip3 install --break-system-packages PyQt6 requests
```

## 更新機制說明

目前 `version.json` 裡面的 `update_url` 先留空。

之後你可以把新版 ZIP 放到 GitHub / Google Drive / OneDrive，再把連結填入 `version.json`。

## Shioaji 預留

目前有：
- `market_source.py`
- `future_shioaji_adapter.py`

等你申請好永豐 API Key 後，再把真實行情接進來。
